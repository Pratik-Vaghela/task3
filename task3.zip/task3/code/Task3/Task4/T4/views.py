from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth.models import User
from django.shortcuts import render

class SignupView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        pass

class LoginView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        pass

class DashboardView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        return Response({"message": "Welcome!"})

def login_signup_page(request):
    return render(request, "login_signup.html")
